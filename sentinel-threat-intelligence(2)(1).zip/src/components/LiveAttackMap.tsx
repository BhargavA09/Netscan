import React, { useEffect, useState, useRef } from 'react';
import { APIProvider, Map, AdvancedMarker, useMap, useMapsLibrary } from '@vis.gl/react-google-maps';
import { ShieldAlert, Globe, Crosshair, Zap } from 'lucide-react';
import { cn } from '../lib/utils';
import { fetchJson } from '../lib/api';

const API_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

interface AttackPoint {
  id: string;
  source: { lat: number; lng: number };
  target: { lat: number; lng: number };
  type: string;
  country?: string;
}

function AttackLines({ attacks }: { attacks: AttackPoint[] }) {
  const map = useMap();
  const mapsLib = useMapsLibrary('maps');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);

  useEffect(() => {
    if (!map || !mapsLib || !attacks.length) return;

    // Clear old lines
    polylinesRef.current.forEach(p => p.setMap(null));
    polylinesRef.current = [];

    attacks.forEach(attack => {
      const line = new google.maps.Polyline({
        path: [attack.source, attack.target],
        geodesic: true,
        strokeColor: attack.type.toLowerCase().includes('botnet') ? '#ef4444' : 
                     attack.type.toLowerCase().includes('malware') ? '#f59e0b' : '#00ff41',
        strokeOpacity: 0.6,
        strokeWeight: 2,
        map: map
      });
      polylinesRef.current.push(line);
    });

    return () => polylinesRef.current.forEach(p => p.setMap(null));
  }, [map, mapsLib, attacks]);

  return null;
}

export function LiveAttackMap() {
  const [attacks, setAttacks] = useState<AttackPoint[]>([]);

  useEffect(() => {
    const fetchAttacks = async () => {
      try {
        const data = await fetchJson<any[]>('/api/attack-map');
        if (Array.isArray(data)) {
          setAttacks(data);
        }
      } catch (error) {
        console.error('Error fetching attack map data:', error);
      }
    };

    fetchAttacks();
    const interval = setInterval(fetchAttacks, 3000);
    return () => clearInterval(interval);
  }, []);

  if (!hasValidKey) {
    return (
      <div className="bg-card border border-border rounded-xl h-[600px] flex items-center justify-center p-8 text-center">
        <div className="max-w-md">
          <Globe className="w-12 h-12 text-zinc-700 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-4">Google Maps API Key Required</h2>
          <p className="text-sm text-zinc-500 mb-6">
            To view the live cyber attack map, please add your Google Maps Platform API key to the project secrets.
          </p>
          <div className="bg-black/40 border border-border rounded-lg p-4 text-left text-xs font-mono space-y-2">
            <p>1. Open Settings (⚙️) → Secrets</p>
            <p>2. Add <code className="text-accent">GOOGLE_MAPS_PLATFORM_KEY</code></p>
            <p>3. Paste your key and press Enter</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 bg-card border border-border rounded-xl overflow-hidden h-[600px] relative">
          <APIProvider apiKey={API_KEY} version="weekly">
            <Map
              defaultCenter={{ lat: 20, lng: 0 }}
              defaultZoom={2}
              mapId="SENTINEL_ATTACK_MAP"
              gestureHandling={'greedy'}
              disableDefaultUI={true}
              styles={mapStyles}
              internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
              className="w-full h-full"
            >
              <AttackLines attacks={attacks} />
              {attacks.map(attack => (
                <React.Fragment key={attack.id}>
                  <AdvancedMarker position={attack.source}>
                    <div className="w-2 h-2 bg-critical rounded-full animate-ping" />
                  </AdvancedMarker>
                  <AdvancedMarker position={attack.target}>
                    <div className="w-3 h-3 bg-accent rounded-full shadow-[0_0_10px_#00ff41]" />
                  </AdvancedMarker>
                </React.Fragment>
              ))}
            </Map>
          </APIProvider>

          {/* Map Overlay */}
          <div className="absolute top-4 left-4 z-10 space-y-2">
            <div className="bg-black/80 backdrop-blur-md border border-border p-3 rounded-lg flex flex-col gap-1">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
                <span className="text-[10px] font-mono text-white uppercase tracking-widest">OSINT Attack Stream</span>
              </div>
              <span className="text-[8px] font-mono text-zinc-500 uppercase">Source: Abuse.ch ThreatFox</span>
            </div>
          </div>

          <div className="absolute bottom-4 right-4 z-10">
            <div className="bg-black/80 backdrop-blur-md border border-border p-4 rounded-lg space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-critical rounded-full" />
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Attack Source</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-accent rounded-full" />
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Target Node</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-card border border-border p-6 rounded-xl">
            <h3 className="text-white font-medium mb-4 flex items-center gap-2 text-sm">
              <Crosshair className="w-4 h-4 text-accent" />
              Active Threats (OSINT)
            </h3>
            <div className="space-y-4">
              {attacks.slice(0, 8).map(attack => (
                <div key={attack.id} className="flex items-center justify-between group border-b border-white/5 pb-2 last:border-0">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-mono text-white">ID_{attack.id.slice(0, 6)}</p>
                      {attack.country && (
                        <span className="text-[8px] font-mono bg-white/5 px-1 rounded text-zinc-400">
                          {attack.country}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] font-mono text-zinc-500 uppercase truncate max-w-[150px]">
                      {attack.type}
                    </p>
                  </div>
                  <Zap className={cn(
                    "w-3 h-3 transition-colors",
                    attack.type.toLowerCase().includes('botnet') ? "text-critical" : "text-accent"
                  )} />
                </div>
              ))}
              {attacks.length === 0 && (
                <div className="py-8 text-center text-zinc-600 text-[10px] font-mono uppercase">
                  Synchronizing with ThreatFox...
                </div>
              )}
            </div>
          </div>

          <div className="bg-card border border-border p-6 rounded-xl">
            <h3 className="text-white font-medium mb-4 flex items-center gap-2 text-sm">
              <ShieldAlert className="w-4 h-4 text-critical" />
              Global Risk Level
            </h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500 uppercase">
                <span>Threat Density</span>
                <span className="text-critical">High</span>
              </div>
              <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-critical w-[75%] animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const mapStyles = [
  {
    "elementType": "geometry",
    "stylers": [{ "color": "#1d2c4d" }]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [{ "color": "#8ec3b9" }]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [{ "color": "#1a3646" }]
  },
  {
    "featureType": "administrative.country",
    "elementType": "geometry.stroke",
    "stylers": [{ "color": "#4b6878" }]
  },
  {
    "featureType": "landscape.man_made",
    "elementType": "geometry.stroke",
    "stylers": [{ "color": "#334e62" }]
  },
  {
    "featureType": "landscape.natural",
    "elementType": "geometry",
    "stylers": [{ "color": "#023e58" }]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [{ "color": "#0e1626" }]
  }
];
