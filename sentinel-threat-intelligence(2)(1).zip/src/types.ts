export interface Threat {
  id: string;
  type: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  source?: string;
  timestamp: string;
  message: string;
  status?: 'Active' | 'Mitigated' | 'Investigating';
  indicators?: string[];
}

export interface IoC {
  value: string;
  type: 'IP' | 'Domain' | 'Hash' | 'URL';
  reputation: 'Malicious' | 'Suspicious' | 'Clean' | 'Unknown';
  lastSeen: string;
  tags: string[];
  source?: string;
}

export interface AnalysisResult {
  summary: string;
  riskScore: number;
  recommendations: string[];
  relatedTechniques: string[];
}

export interface TTP {
  id: string;
  name: string;
  description: string;
  mitreUrl?: string;
}

export interface ThreatActor {
  id: string;
  name: string;
  aliases: string[];
  origin: string;
  targetSectors: string[];
  motivations: string[];
  ttps: TTP[];
  description: string;
  lastActive: string;
}
